import cv2

name = 'Aston_Kutcher' #replace with your name and create folder before executing

cam = cv2.VideoCapture(0)

cv2.namedWindow("sakatu SPACE argazkia ateratzeko", cv2.WINDOW_NORMAL)
cv2.resizeWindow("sakatu SPACE argazkia ateratzeko", 500, 300)

img_counter = 0

while True:
    ret, frame = cam.read()
    if not ret:
        print("failed to grab frame")
        break
    cv2.imshow("sakatu SPACE argazkia ateratzeko", frame)

    k = cv2.waitKey(1)
    if k%256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        break
    elif k%256 == 32:
        # SPACE pressed
        img_name = "dataset/"+ name +"/image_{}.jpg".format(img_counter)
        cv2.imwrite(img_name, frame)
        print("{} written!".format(img_name))
        img_counter += 1

cam.release()

cv2.destroyAllWindows()
