
# Google Drive Spread Sheet management

# importing the required libraries
import gspread 
import pandas as pd  #spreadsheet management
from oauth2client.service_account import ServiceAccountCredentials
import datetime
import time


# define the scope
scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']

# add credentials to the account
creds = ServiceAccountCredentials.from_json_keyfile_name('elevatorimh-d33b18a80991.json', scope)

# authorize the clientsheet 
client = gspread.authorize(creds)

# get the instance of the Spreadsheet
sheet = client.open('DB_Elevator_Face')

# get the first sheet of the Spreadsheet
DB_Elevator_Face = sheet.get_worksheet(0)

# get the value at the specific cell

#Num_Rows =DB_Elevator_Face.cell(col=6,row=1)
Num_Rows_str = DB_Elevator_Face.acell('F1').value #number of rows INDEX in the spreadsheet DO NOT CHANGE MANUALLY 

Num_Rows = int(Num_Rows_str)
DB_Elevator_Face.add_rows(1)
Nun_Rows = Num_Rows + 1

Date = datetime.datetime.now()

DB_Elevator_Face.update_cell(Nun_Rows, 1, str(Date)) #update_cell (row,column,value)
DB_Elevator_Face.update_cell(Nun_Rows, 3, '5') #update_cell (row,column,value) Joseba= 3rd col

Num_Rows_str = str(Nun_Rows)
DB_Elevator_Face.update('F1', Num_Rows_str ) #number of rows INDEX update

DB_Elevator_Face.update('H1', '5' ) #H1 Floor Command updatefor 2 sec
time.sleep(2)
DB_Elevator_Face.update('H1', '0' )
  

  
    

## >> <Cell R2C3 '63881'>

