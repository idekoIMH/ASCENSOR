
# Google Drive Spread Sheet management

# importing the required libraries
import gspread 
import pandas as pd  #spreadsheet management
from oauth2client.service_account import ServiceAccountCredentials
import datetime
import time


# define the scope
scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']

# add credentials to the account
creds = ServiceAccountCredentials.from_json_keyfile_name('elevatorimh-d33b18a80991.json', scope)

# authorize the clientsheet 
client = gspread.authorize(creds)

# get the instance of the Spreadsheet
sheet = client.open('DB Elevator')

# get the first sheet of the Spreadsheet
DB_Elevator_Face = sheet.get_worksheet(0)

#get the value at the specific cell

    #Num_Rows =DB_Elevator_Face.cell(col=6,row=1)
    Num_Rows_str = DB_Elevator_Face.acell('L5').value #number of rows INDEX in the spreadsheet DO NOT CHANGE MANUALLY 

    Num_Rows = int(Num_Rows_str)
    # DB_Elevator_Face.add_rows(1)
    Nun_Rows = Num_Rows + 1

    Date = datetime.datetime.now()

    DB_Elevator_Face.update_cell(Nun_Rows, 1, str(Date)) #update_cell (row,column,value)
    DB_Elevator_Face.update_cell(Nun_Rows, 8, '6') #update_cell (row,column,value) Bellanco= 4th col

    Num_Rows_str = str(Nun_Rows)
    DB_Elevator_Face.update('L5', Num_Rows_str ) #number of rows INDEX update

    DB_Elevator_Face.update('N5', '6' ) #H1 Floor Command updatefor 2 sec
    time.sleep(2)
    DB_Elevator_Face.update('N5', '0' )
  

    

## >> <Cell R2C3 '63881'>

