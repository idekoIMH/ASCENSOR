import cv2
import imutils


cam = cv2.VideoCapture(0)

#cv2.namedWindow("press space to take a photo", cv2.WINDOW_NORMAL)
cv2.resizeWindow("press space to take a photo", 2160, 1840)

img_counter = 0

while True:
    ret, frame = cam.read()
    if not ret:
        print("failed to grab frame")
        break
        
    frame = imutils.resize(frame, width=1000)
    cv2.imshow("ESC irtetzeko", frame)

    k = cv2.waitKey(1)
    if k%256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        break
 

cam.release()

cv2.destroyAllWindows()
