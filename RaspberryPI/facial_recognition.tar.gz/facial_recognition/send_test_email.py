#! /usr/bin/python

# Imports
import requests

def send_simple_message():
    print("I am sending an email.")
    return requests.post(
        "https://api.mailgun.net/v3/sandboxa6ff0163e1bb4178941394eb4218e548.mailgun.org/messages",
        auth=("api", "877ab1dd47a7d9e0ba1ba4d5bf669ff9-ba042922-d079dfe5"),
        data={"from": 'hello@example.com',
            "to": ["ozaeta2pbe@gmail.com"],
            "subject": "Visitor Alert",
            "html": "<html> Your Raspberry Pi recognizes someone. </html>"})
                      
request = send_simple_message()
print ('Status: '+format(request.status_code))
print ('Body:'+ format(request.text))
